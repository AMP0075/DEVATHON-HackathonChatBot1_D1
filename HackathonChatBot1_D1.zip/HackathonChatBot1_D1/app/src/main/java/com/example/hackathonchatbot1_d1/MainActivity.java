package com.example.hackathonchatbot1_d1;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {

    private TextView AppName1;
    private TextView logInf;
    private EditText UserName;
    private TextView pasInf;
    private EditText Pswrd;
    private Button Loginbut;
    private TextView Frgtpswrd;
    private TextView Atmptctr;
    private Button FacBtn;
    private Button GBtn;
    private int counter = 5;
    private TextView userRegistration;
    private FirebaseAuth firebaseAuth;
    private ProgressDialog progressDialog;
    private TextView forgotPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        AppName1 = (TextView) findViewById(R.id.AppName);
        logInf = (TextView) findViewById(R.id.textView4);
        UserName = (EditText) findViewById(R.id.usrEmailINP);
        pasInf = (TextView) findViewById(R.id.textView5);
        Pswrd = (EditText) findViewById(R.id.usrPswrdINP);
        Loginbut = (Button) findViewById(R.id.usrlogin);
        Frgtpswrd = (TextView) findViewById(R.id.tvForgotPassword);
        Atmptctr = (TextView) findViewById(R.id.attemptcounter);
        FacBtn = (Button) findViewById(R.id.fbtn);
        GBtn = (Button) findViewById(R.id.gbtn);
        userRegistration = (TextView)findViewById(R.id.tvRegister1) ;
        forgotPassword = (TextView)findViewById(R.id.tvForgotPassword);

        Atmptctr.setText("No. of attempts remaining : 5");

        firebaseAuth = FirebaseAuth.getInstance();

        progressDialog = new ProgressDialog(this);

        FirebaseUser user = firebaseAuth.getCurrentUser();

        if(user != null)
        {
            finish();
            startActivity(new Intent(MainActivity.this, MainPage.class));
        }

        Loginbut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                validate(UserName.getText().toString(),Pswrd.getText().toString());
            }
        });

        userRegistration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this,RegistrationActivity.class));
                counter = 5;
                Atmptctr.setText("  No. of Unsuccessful Attempts Remaining : 5");
            }
        });

        forgotPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this,PasswordActivity.class
                ));
                counter=5;
                Atmptctr.setText("  No. of Unsuccessful Attempts Remaining : 5");
            }
        });

        Atmptctr.setText("  No. of Unsuccessful Attempts Remaining : 5");

    }
    private void validate(String user , String paswrd)
    {
        progressDialog.setMessage("Loading...");
        progressDialog.show();

        firebaseAuth.signInWithEmailAndPassword(user,paswrd).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful())
                {
                    progressDialog.dismiss();
                    checkEmailVerification();
                }
                else
                {
                    Toast.makeText(MainActivity.this,"Login Failed",Toast.LENGTH_SHORT).show();
                    counter --;
                    progressDialog.dismiss();
                    Atmptctr.setText("Number of Attempts Remaining : " + counter);
                    if(counter == 0)
                    {
                        Loginbut.setEnabled(false);
                    }
                }
            }
        });
    }

    private void checkEmailVerification()
    {
        FirebaseUser firebaseUser = firebaseAuth.getInstance().getCurrentUser();
        Boolean emailflag = firebaseUser.isEmailVerified();

        if(emailflag)
        {
            finish();
            startActivity(new Intent(MainActivity.this, MainPage.class));
        }
        else
        {
            Toast.makeText(this,"Verify Your Email",Toast.LENGTH_SHORT);
            firebaseAuth.signOut();
        }
    }
}
